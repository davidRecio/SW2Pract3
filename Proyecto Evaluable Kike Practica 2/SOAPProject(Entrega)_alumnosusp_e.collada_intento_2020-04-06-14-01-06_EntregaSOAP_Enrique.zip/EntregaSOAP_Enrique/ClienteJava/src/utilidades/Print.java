/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utilidades;

import serviceuni.Asignatura;

/**
 *
 * @author enrique
 */
public class Print {

    public String printAsignaturas(Asignatura asig) {
        
        return "Asignatura:" + "Nombre: " + asig.getNombreAsignatura() + ", curso: " + asig.getCurso() + ", profesor: " + asig.getProfesor()
                + ", créditos: " + asig.getCreditos();
    }
    
}
