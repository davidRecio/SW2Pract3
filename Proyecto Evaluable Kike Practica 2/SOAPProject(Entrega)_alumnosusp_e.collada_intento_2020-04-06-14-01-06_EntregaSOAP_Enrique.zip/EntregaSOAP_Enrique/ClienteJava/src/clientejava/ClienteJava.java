/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientejava;

import java.util.ArrayList;
import java.util.Scanner;
import serviceuni.Asignatura;
import serviceuni.Carrera;
import serviceuni.ServiciosUniversidad;
import serviceuni.ServiciosUniversidad_Service;
import utilidades.Print;
import utilidades.StringToXML;
import utilidades.XMLToString;

/**
 *
 * @author enrique
 */
public class ClienteJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic
        Scanner scanner = new Scanner(System.in);
        Carrera carr = new Carrera();
        ServiciosUniversidad_Service service = new ServiciosUniversidad_Service();

        System.out.println("\nPor favor, escriba:\n1 para crear una carrera\n2 para introducir una asignatura\n3"
                + " para ver las asignaturas\n4 para ver información de una asignatura\n5 para importar las asignaturas\n6 para exportar las asignaturas introducidas"
                + "\n7 para importar una asignatura concreta"
                + "\n8 para exportar una asignatura concreta\n0 para salir del programa\n");
        String opcion = scanner.nextLine();

        while (!opcion.equals("0")) {

            if (opcion.equals("1")) {

                System.out.println("\nPor favor, introduzca el nombre de la carrera:");
                String nombreCarrera = scanner.nextLine();
                carr.setNombreCarrera(nombreCarrera);

                System.out.println("\nPor favor, introduzca la facultad:");
                String facultad = scanner.nextLine();
                carr.setFacultad(facultad);

                System.out.println("\nPor favor, introduzca el nombre de la universidad:");
                String universidad = scanner.nextLine();
                carr.setUniversidad(universidad);

                System.out.println("\nPor favor, introduzca la nota de corte:");
                Integer notaCorte = scanner.nextInt();
                scanner.nextLine();
                carr.setNotaCorte(notaCorte);

                ServiciosUniversidad serv_uni = service.getServiciosUniversidadPort();
//                Carrera carreraCreada = serv_uni.crearCarrera(carr);
                serv_uni.crearCarrera(carr);

            } else if (opcion.equals("2")) {
                Asignatura asig = new Asignatura();

                System.out.println("\nPor favor, introduzca el nombre de la asignatura:");
                String nombreAsignatura = scanner.nextLine();
                asig.setNombreAsignatura(nombreAsignatura);

                System.out.println("\nPor favor, introduzca el curso de la asignatura:");
                Integer curso = scanner.nextInt();
                scanner.nextLine();
                asig.setCurso(curso);

                System.out.println("\nPor favor, introduzca el profesor de la asignatura:");
                String profesor = scanner.nextLine();
                asig.setProfesor(profesor);

                System.out.println("\nPor favor, introduzca el número de créditos de la asignatura:");
                Integer creditos = scanner.nextInt();
                scanner.nextLine();
                asig.setCreditos(creditos);

                ServiciosUniversidad serv_uni = service.getServiciosUniversidadPort();
                serv_uni.crearAsignatura(asig);
            } else if (opcion.equals("3")) {
                ServiciosUniversidad serv_uni = service.getServiciosUniversidadPort();
                Carrera carrera = serv_uni.devolverCarrera();
                Print p = new Print();
                System.out.println(carrera.getAsignaturas().size());
                ArrayList<Asignatura> asignaturas = (ArrayList<Asignatura>) carrera.getAsignaturas();
                for (int i = 0; i < asignaturas.size(); i++) {
                    System.out.println(p.printAsignaturas(asignaturas.get(i)));
                }
            } else if (opcion.equals("4")) {
                ServiciosUniversidad serv_uni = service.getServiciosUniversidadPort();
                Carrera carrera = serv_uni.devolverCarrera();
                ArrayList<Asignatura> asignaturas = (ArrayList<Asignatura>) carrera.getAsignaturas();
                for (int i = 0; i < asignaturas.size(); i++) {
                    int n = i + 1;
                    System.out.println("" + n + ". " + asignaturas.get(i).getNombreAsignatura());
                }
                System.out.println("\nPor favor, introduzca el número de la asignatura que desea ver");
                Integer n = scanner.nextInt();
                scanner.nextLine();
                Asignatura asig = serv_uni.devolverAsignatura(n);
//                Asignatura asig = serv_uni.devolverAsignatura(nombreAsignatura);
                Print p = new Print();
                System.out.println(p.printAsignaturas(asig));

            } else if (opcion.equals("5")) {

                System.out.println("\nPor favor, introduzca el nombre del archivo del que desea importar los datos:");
                String nombreArchivo = scanner.nextLine();
                String xmlFile;
                XMLToString xs = new XMLToString();
                xmlFile = xs.xmlToString(nombreArchivo);

                ServiciosUniversidad serv_uni = service.getServiciosUniversidadPort();
                serv_uni.importarCarrera(xmlFile);
//                Carrera c;
//                UnMarshaling un = new UnMarshaling();
//                CarreraCliente cc = un.unMarshaling(nombreArchivo);
//                serv_uni.crearCarrera(c);

            } else if (opcion.equals("6")) {

                System.out.println("\nPor favor, introduzca el nombre que desea para el archivo xml:");
                String nombreArchivo = scanner.nextLine();

//                Marshaling mars = new Marshaling();
                ServiciosUniversidad serv_uni = service.getServiciosUniversidadPort();
                Carrera c = serv_uni.devolverCarrera();
                String xmlString = serv_uni.exportarCarrera(c);

                StringToXML sx = new StringToXML();
                sx.stringToDom(xmlString, nombreArchivo);
//                mars.marshaling(c, nombreArchivo);

            } else if (opcion.equals("7")) {

                Asignatura asig;
                System.out.println("\nPor favor, introduzca el nombre de la asignatura que desea importar:");
                String nombreArchivo = scanner.nextLine();
                String xmlFile;
                XMLToString xs = new XMLToString();
                xmlFile = xs.xmlToString(nombreArchivo);

                ServiciosUniversidad serv_uni = service.getServiciosUniversidadPort();
                serv_uni.importarAsignatura(xmlFile);
//                UnMarshaling un = new UnMarshaling();
//                asig = un.unMarshalingAsig(nombreArchivo);
//                serv_uni.crearAsignatura(asig);

            } else if (opcion.equals("8")) {
                ServiciosUniversidad serv_uni = service.getServiciosUniversidadPort();
                Asignatura asig;
                ArrayList<Asignatura> asignaturas = (ArrayList<Asignatura>) serv_uni.devolverCarrera().getAsignaturas();
                for (int i = 0; i < asignaturas.size(); i++) {
                    int n = i + 1;
                    System.out.println("" + n + ". " + asignaturas.get(i).getNombreAsignatura());
                }
                System.out.println("\nPor favor, introduzca el número correspondiente a la asignatura que desea exportar");
                Integer numAs = scanner.nextInt();
                scanner.nextLine();
                asig = (Asignatura) serv_uni.devolverAsignatura(numAs);
                System.out.println(asig.getNombreAsignatura());

                System.out.println("\nPor favor, introduzca el nombre de la asignatura que desea exportar a un archivo xml");
                String nombreArchivo = scanner.nextLine();

                String xmlString = serv_uni.exportarAsignatura(asig);
                StringToXML sx = new StringToXML();
                sx.stringToDom(xmlString, nombreArchivo);

//                Marshaling mars = new Marshaling();
//                mars.marshalingAsignatura(asig, nombreArchivo);
            }

            System.out.println("\nPor favor, escriba:\n1 para crear una carrera\n2 para introducir una asignatura\n3"
                    + " para ver las asignaturas\n4 para ver información de una asignatura\n5 para importar las asignaturas\n6 para exportar las asignaturas introducidas"
                    + "\n7 para importar una asignatura concreta"
                    + "\n8 para exportar una asignatura concreta\n0 para salir del programa\n");
            opcion = scanner.nextLine();
        }
    }
}
