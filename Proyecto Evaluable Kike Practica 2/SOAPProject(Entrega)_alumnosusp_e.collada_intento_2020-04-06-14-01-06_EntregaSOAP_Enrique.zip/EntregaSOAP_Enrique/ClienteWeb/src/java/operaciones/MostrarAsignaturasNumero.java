/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operaciones;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import serviceuni.Asignatura;
import serviceuni.ServiciosUniversidad;
import serviceuni.ServiciosUniversidad_Service;

/**
 *
 * @author enrique
 */
public class MostrarAsignaturasNumero extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet MostrarAsignaturasNumero</title>");
            out.println("</head>");
            out.println("<body>");

            ServiciosUniversidad_Service service = new ServiciosUniversidad_Service();
            ServiciosUniversidad serv_uni = service.getServiciosUniversidadPort();
            ArrayList<Asignatura> asignaturas = (ArrayList<Asignatura>) serv_uni.devolverCarrera().getAsignaturas();
            for (int i = 0; i < asignaturas.size(); i++) {
                int n = i + 1;
                out.println("<p>" + n + ". " + asignaturas.get(i).getNombreAsignatura() + "</p>");
            }
            out.println("        <form action=\"ExportarAsignatura\" method=\"GET\">\n"
                    + "            Indique el numero de la asignatura que desea exportar: <input type=\"text\" name=\"numAs\"><br>\n"
                    + "            Ruta y nombre del fichero en el que desea exportar la asignatura: <input type=\"text\" name=\"nombreFichero\"><br>\n"
                    + "                        <p>"
                    + "            <i>Ejemplo macOS: /Users/enrique/NetBeansProjects/ClienteWeb/xml/ssw2.xml</i></p>"
                    + "            <p><i>Ejemplo Windows: C:\\Users\\ferna\\OneDrive\\Escritorio\\EntregaSOAP_Enrique\\ClienteWeb\\xml\\ssw2.xml</i></p>"
                    + "            <br>\n"
                    + "            <input type=\"submit\" value=\"Exportar\">\n"
                    + "        </form>");
            out.println("</body>");
            out.println("</html>");

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
