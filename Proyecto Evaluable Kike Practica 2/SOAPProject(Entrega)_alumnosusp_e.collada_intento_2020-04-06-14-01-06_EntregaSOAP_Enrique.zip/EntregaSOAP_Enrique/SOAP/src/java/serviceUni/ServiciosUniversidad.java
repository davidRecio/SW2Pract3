/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serviceUni;

import java.util.ArrayList;
import javax.jws.WebMethod;
import javax.jws.WebService;
import operaciones.Marshaling;
import operaciones.UnMarshaling;
import uni.Asignatura;
import uni.Carrera;

/**
 *
 * @author enrique
 */
@WebService(serviceName = "ServiciosUniversidad")
public class ServiciosUniversidad {

    public Carrera carreraServ;

    @WebMethod(operationName = "devolverCarrera")
    public Carrera devolverCarrera() {
        return carreraServ;
    }

    @WebMethod(operationName = "crearCarrera")
    public Carrera crearCarrera(Carrera carrera) {
        carreraServ = carrera;
        System.out.println("Creando carrera...");
        return carreraServ;
    }

    @WebMethod(operationName = "crearAsignatura")
    public Asignatura crearAsignatura(Asignatura asignatura) {
        ArrayList<Asignatura> asignaturas = carreraServ.getAsignaturas();
        asignaturas.add(asignatura);
        return asignatura;
    }

//    @WebMethod(operationName = "devolverAsignatura")  //ID
//    public Asignatura devolverAsignatura(String nombre) {
//        Asignatura asignatura = null;
//        ArrayList<Asignatura> array = carreraServ.getAsignaturas();
//        for (int i = 0; i < array.size(); i++) {
//            if (array.get(i).getNombreAsignatura().equalsIgnoreCase(nombre)) {
//                asignatura = array.get(i);
//            }
//            return asignatura;
//        }
//        return asignatura;
//    }
    @WebMethod(operationName = "devolverAsignatura")  //ID
    public Asignatura devolverAsignatura(Integer n) {
        Asignatura asignatura = null;
        ArrayList<Asignatura> array = carreraServ.getAsignaturas();
        asignatura = array.get(n-1);
        return asignatura;
    }

    @WebMethod(operationName = "exportarCarrera")
    public String exportarCarrera(Carrera carr) {
        Marshaling mars = new Marshaling();
//        carr = this.devolverCarrera();
        String xmlString = mars.marshaling(carr);
        return xmlString;
    }

    @WebMethod(operationName = "exportarAsignatura")
    public String exportarAsignatura(Asignatura asig) {
        Marshaling mars = new Marshaling();
        String xmlString = mars.marshalingAsignatura(asig);
        return xmlString;
    }

    @WebMethod(operationName = "importarCarrera")
    public void importarCarrera(String xmlString) {
        Carrera carr;
        Asignatura asig;
        UnMarshaling un = new UnMarshaling();
        carr = un.unMarshaling(xmlString);
        this.crearCarrera(carr);
    }

    @WebMethod(operationName = "importarAsignatura")
    public void importarAsignatura(String xmlString) {
        Asignatura asig;
        UnMarshaling un = new UnMarshaling();
        asig = un.unMarshalingAsig(xmlString);
        this.crearAsignatura(asig);
    }

}
