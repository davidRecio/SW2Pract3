/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operaciones;

import java.io.File;
import java.io.StringReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import uni.Asignatura;
import uni.Carrera;

/**
 *
 * @author enrique
 */
public class UnMarshaling {

    public Carrera unMarshaling(String xmlString) {
        Carrera carrera = new Carrera();
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(Carrera.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

            //We had written this file in marshalling example
//            carrera = (Carrera) jaxbUnmarshaller.unmarshal(new File("./xml/" + nombreArchivo + ".xml"));
            StringReader reader = new StringReader(xmlString);
            carrera = (Carrera) jaxbUnmarshaller.unmarshal(reader);
            System.out.println(carrera);

        } catch (JAXBException ex) {
            Logger.getLogger(UnMarshaling.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return carrera;
    }

    public Asignatura unMarshalingAsig(String xmlString) {
        Asignatura asig = null;
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(Asignatura.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

            //We had written this file in marshalling example
//            carrera = (Carrera) jaxbUnmarshaller.unmarshal(new File("./xml/" + nombreArchivo + ".xml"));
            StringReader reader = new StringReader(xmlString);
            asig = (Asignatura) jaxbUnmarshaller.unmarshal(reader);
            System.out.println(asig);

        } catch (JAXBException ex) {
            Logger.getLogger(UnMarshaling.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return asig;
    }

}
