/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package operaciones;

import java.io.File;
import java.io.StringWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;
import uni.Asignatura;
import uni.Carrera;

/**
 *
 * @author enrique
 */
public class Marshaling {

    public String marshaling(Carrera carr) {
        
        String xmlString = null;
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(Carrera.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            //Marshal the employees list in console
            jaxbMarshaller.marshal(carr, System.out);

            //Marshal the employees list in file
            StringWriter sw = new StringWriter();
            jaxbMarshaller.marshal(carr, sw);
            xmlString = sw.toString();
        } catch (PropertyException ex) {
            Logger.getLogger(Marshaling.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JAXBException ex) {
            Logger.getLogger(Marshaling.class.getName()).log(Level.SEVERE, null, ex);
        }
        return xmlString;
    }

    public String marshalingAsignatura(Asignatura asig) {
        
        String xmlString = null;
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(Asignatura.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            //Marshal the employees list in console
            jaxbMarshaller.marshal(asig, System.out);

            //Marshal the employees list in file
            StringWriter sw = new StringWriter();
            jaxbMarshaller.marshal(asig, sw);
            xmlString = sw.toString();
        } catch (PropertyException ex) {
            Logger.getLogger(Marshaling.class.getName()).log(Level.SEVERE, null, ex);
        } catch (JAXBException ex) {
            Logger.getLogger(Marshaling.class.getName()).log(Level.SEVERE, null, ex);
        }
        return xmlString;
    }

}
