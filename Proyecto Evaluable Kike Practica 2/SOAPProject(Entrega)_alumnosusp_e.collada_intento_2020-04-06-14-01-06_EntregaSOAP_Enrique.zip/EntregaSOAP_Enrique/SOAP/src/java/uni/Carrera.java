/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uni;

import java.io.Serializable;
import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author enrique
 */
@XmlAccessorType (XmlAccessType.FIELD)
@XmlRootElement(name="carrera")
public class Carrera implements Serializable{
//        @XmlElementWrapper(name="asignaturas")
    @XmlElement
    private ArrayList<Asignatura> asignaturas;
    @XmlElement
    private String nombreCarrera;
    @XmlElement
    private String facultad;
    @XmlElement
    private String universidad;
    @XmlElement
    private Integer notaCorte;
    
    public void annadirAsignatura(Asignatura asig){
    
        if(asignaturas == null){
            asignaturas = new ArrayList();
        } else {
            asignaturas.add(asig);
        }
    
    }

    public Carrera() {
                    asignaturas = new ArrayList();
    }
    

    /**
     * @return the asignatura
     */
    public ArrayList getAsignaturas() {
        return asignaturas;
    }

    /**
     * @param asignatura the asignatura to set
     */
    public void setAsignaturas(ArrayList asignatura) {
        this.asignaturas = asignatura;
    }

    /**
     * @return the nombreCarrera
     */
    public String getNombreCarrera() {
        return nombreCarrera;
    }

    /**
     * @param nombreCarrera the nombreCarrera to set
     */
    public void setNombreCarrera(String nombreCarrera) {
        this.nombreCarrera = nombreCarrera;
    }

    /**
     * @return the facultad
     */
    public String getFacultad() {
        return facultad;
    }

    /**
     * @param facultad the facultad to set
     */
    public void setFacultad(String facultad) {
        this.facultad = facultad;
    }

    /**
     * @return the universidad
     */
    public String getUniversidad() {
        return universidad;
    }

    /**
     * @param universidad the universidad to set
     */
    public void setUniversidad(String universidad) {
        this.universidad = universidad;
    }

    /**
     * @return the notaCorte
     */
    public Integer getNotaCorte() {
        return notaCorte;
    }

    /**
     * @param notaCorte the notaCorte to set
     */
    public void setNotaCorte(Integer notaCorte) {
        this.notaCorte = notaCorte;
    }

    @Override
    public String toString() {
        return "Carrera{" + "asignaturas=" + asignaturas + ", nombreCarrera=" + nombreCarrera + ", facultad=" + facultad + ", universidad=" + universidad + ", notaCorte=" + notaCorte + '}';
    }

    
}