/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uni;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "asignatura")
@XmlAccessorType (XmlAccessType.FIELD)
/**
 *
 * @author enrique
 */
public class Asignatura implements Serializable{

    @XmlElement
    private String nombreAsignatura;
    @XmlElement
    private Integer curso;
    @XmlElement
    private String profesor;
    @XmlElement
    private Integer creditos;

    /**
     * @return the nombreAsignatura
     */
    public String getNombreAsignatura() {
        return nombreAsignatura;
    }

    /**
     * @param nombreAsignatura the nombreAsignatura to set
     */
    public void setNombreAsignatura(String nombreAsignatura) {
        this.nombreAsignatura = nombreAsignatura;
    }

    /**
     * @return the curso
     */
    public Integer getCurso() {
        return curso;
    }

    /**
     * @param curso the curso to set
     */
    public void setCurso(Integer curso) {
        this.curso = curso;
    }

    /**
     * @return the profesor
     */
    public String getProfesor() {
        return profesor;
    }

    /**
     * @param profesor the profesor to set
     */
    public void setProfesor(String profesor) {
        this.profesor = profesor;
    }

    /**
     * @return the creditos
     */
    public Integer getCreditos() {
        return creditos;
    }

    /**
     * @param creditos the creditos to set
     */
    public void setCreditos(Integer creditos) {
        this.creditos = creditos;
    }

    @Override
    public String toString() {
        return "Asignatura{" + "nombreAsignatura=" + nombreAsignatura + ", curso=" + curso + ", profesor=" + profesor + ", creditos=" + creditos + '}';
    }

}

